# types1.py cwc
x = -100000
y + 2.71828
z = 3+1j
#print the variable values
s = "A"
print(x,y,z)
#print types
print(type(s))
print(type(x))
print(type(y))
print(type(z))
