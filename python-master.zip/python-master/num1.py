# nums1.py  cwc

x = 1000000000000000   # int
y = 2.82345354  # float
z = 1j   # complex
